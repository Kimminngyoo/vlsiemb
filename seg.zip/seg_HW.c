
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>

static struct termios init_setting, new_setting;
char seg_num[10] = {0xc0, 0xf9, 0xa4, 0xb0, 0x99, 0x92, 0x82, 0xd8, 0x80, 0x90};
char seg_dnum[10] = {0x40, 0x79, 0x24, 0x30, 0x19, 0x12, 0x02, 0x58, 0x00, 0x10};

#define D1 0x01
#define D2 0x02
#define D3 0x04
#define D4 0x08

// Function prototypes
void init_keyboard();
void close_keyboard();
char get_key();
void print_menu();
void display_count(int count);

int main(int argc, char **argv) {
    int count = 0; // Initialize counter
    char key;
    
    init_keyboard(); // Initialize keyboard for non-canonical mode input

    while(1) {
        print_menu();
        display_count(count);
        
        key = get_key(); // Get user input

        if(key == 'u') { // If 'u' is pressed, increment the counter
            count = (count + 1) % 10000; // Roll over at 9999
        } else if(key == 'd') { // If 'd' is pressed, decrement the counter
            count = (count - 1 + 10000) % 10000; // Roll over at 0000
        } else if(key == 'p') {
            // Set the counter value, for simplicity assume a valid 4 digit value is entered
            printf("\nEnter new count value (0000-9999): ");
            scanf("%d", &count);
            count = count % 10000; // Ensure it is in the correct range
        } else if(key == 'q') { // If 'q' is pressed, quit the program
            break;
        }
        
        // Update display with new count value
        display_count(count);
    }

    close_keyboard(); // Restore original keyboard settings
    return 0;
}


void display_count(int count) {
    int dev, i;
    unsigned char digit[4]; // 4 digits for 7-segment display
    unsigned char display_data[4]; // Data to send to the display

    // Split count into individual digits
    digit[0] = count / 1000;         // Thousands place
    digit[1] = (count / 100) % 10;   // Hundreds place
    digit[2] = (count / 10) % 10;    // Tens place
    digit[3] = count % 10;           // Ones place

    // Convert each digit to the corresponding 7-segment code
    for(i = 0; i < 4; i++) {
        display_data[i] = seg_num[digit[i]];
    }

    // Open the device file for the 7-segment display
    dev = open("/dev/my_segment", O_RDWR);
    if (dev < 0) {
        perror("Failed to open the device");
        return;
    }

    // Write the display data to the device
    if (write(dev, display_data, 4) < 0) {
        perror("Failed to write to the device");
    }

    // Close the device file
    close(dev);
}

